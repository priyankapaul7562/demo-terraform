# Networking Codelab

The Terraform configuration in this directory is used for a [simple codelab](https://codelabs.developers.google.com/codelabs/hashicorp-terraform-networking/index.html#0).
