# Simple VPC Network Peering

This example creates a VPC Network peering between two VPCs.

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|:----:|:-----:|:-----:|
| project\_id | The project ID to put the resources in | string | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| peering1 | Peering1 module output. |
| peering2 | Peering2 module output. |

<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
